Cufon.replace('.text', { fontFamily: 'Didact Gothic', hover:true });
Cufon.replace('h2, h3', { fontFamily: 'Shanti', hover:true });

