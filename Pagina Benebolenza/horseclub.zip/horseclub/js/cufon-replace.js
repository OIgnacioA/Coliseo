Cufon.replace('h2, h3, .social-icons span, ul.menu li a , .banner a, .banner p, .box-1 a, .button, .number', { fontFamily: 'Kozuka_L', hover:true});
Cufon.replace('.number', { fontFamily: 'Kozuka_B', hover:true});
